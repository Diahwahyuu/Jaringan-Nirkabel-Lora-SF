#include "TDMALoRaApp.h"

using namespace flora;

Define_Module(TDMALoRaApp)

TDMALoRaApp::TDMALoRaApp() :
    SimpleLoRaApp(),
    slotDuration(1.0),
    cycleDuration(0),
    nodeIndex(0),
    isMySlot(false)
{}

void TDMALoRaApp::initialize(int stage) {
    SimpleLoRaApp::initialize(stage);

    if (stage == INITSTAGE_APPLICATION_LAYER) {
        initializeTDMAParameters();
    }
}

void TDMALoRaApp::initializeTDMAParameters() {
    slotDuration = par("slotDuration").doubleValue();
    cycleDuration = par("cycleDuration").doubleValue();

    nodeIndex = getParentModule()->getIndex();

    currentSlotStart = simTime() + (nodeIndex * slotDuration);

    EV << "Node" << nodeIndex
       << " - Initial Slot Start: " << currentSlotStart
       << ", Slot Duration: " << slotDuration
       << endl;

    if (sendMeasurements) {
        cancelEvent(sendMeasurements);
    }

    sendMeasurements = new cMessage("sendMeasurements");
    scheduleAt(currentSlotStart, sendMeasurements);
}

void TDMALoRaApp::handleMessage(cMessage *msg) {
    if (msg->isSelfMessage() && msg == sendMeasurements) {
        isMySlot = checkIfMySlot();

        if (isMySlot) {
            SimpleLoRaApp::sendJoinRequest();
        }

        currentSlotStart += cycleDuration;
        scheduleAt(currentSlotStart, sendMeasurements);
    } else {
        SimpleLoRaApp::handleMessage(msg);
    }
}

bool TDMALoRaApp::checkIfMySlot() {
    int totalSlots = static_cast<int>(cycleDuration / slotDuration);
    int currentSlot = static_cast<int>((simTime().dbl() / slotDuration)) % totalSlots;

    bool mySlot = (currentSlot == nodeIndex);

    EV << "Node" << nodeIndex
           << " - Current Time: " << simTime()
           << ", Current Slot: " << currentSlot
           << ", Is My Slot: " << (mySlot ? "Yes" : "No")
           << endl;

    return mySlot;
}

//void TDMALoRaApp::sendJoinRequest() {
//    SimpleLoRaApp::sendJoinRequest();
//}
