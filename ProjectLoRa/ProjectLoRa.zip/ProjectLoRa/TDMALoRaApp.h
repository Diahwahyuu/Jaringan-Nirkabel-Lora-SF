#ifndef TDMALORAAPP_H_
#define TDMALORAAPP_H_

#include "LoRaApp/SimpleLoRaApp.h"

using namespace flora;

class TDMALoRaApp : public SimpleLoRaApp {
protected:
    double slotDuration;
    double cycleDuration;
    int nodeIndex;
    simtime_t currentSlotStart;
    bool isMySlot;

    virtual bool checkIfMySlot();
    virtual void initializeTDMAParameters();

    virtual void initialize(int stage) override;
    virtual void handleMessage(cMessage *msg) override;
//    virtual void sendJoinRequest() override;

public:
    TDMALoRaApp();
};

#endif /* TDMALORAAPP_H_ */
